export class ProductoDTO {
    readonly codigo: number;
    readonly nombre: string;
    readonly descripcion: string;
    readonly historia: string;


}
