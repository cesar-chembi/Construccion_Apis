export class CulturaDTO {
    readonly codigo: number;
    readonly nombre: string;
    readonly descripcion: string;

}
