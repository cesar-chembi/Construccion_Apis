export class RecetaDTO {
    readonly codigo: number;
    readonly nombre: string;
    readonly descripcion: string;
    readonly urlFoto: string;
    readonly procesoPrep: string;
    readonly urlVideo: string;

}
