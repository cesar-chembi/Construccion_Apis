export class PaisDto {
    readonly codigo: number;
    readonly nombre: string;
    readonly capital: string;
    readonly bandera: string;


}
