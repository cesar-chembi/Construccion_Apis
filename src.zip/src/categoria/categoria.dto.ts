export class CategoriaDTO {
  readonly codigo: number;
  readonly nombre: string;

}
