export class PremioMichelinDTO {
    readonly codigo: number;
    readonly fechaConsecucion: Date;

}
