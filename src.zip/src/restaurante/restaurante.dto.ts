export class RestauranteDTO {
    readonly codigo: number;
    readonly nombre: string;
    readonly nombreCiudad: String;

}
